@extends('master.app')

@section('main-content')
<h2 class="text-center text-warning ">Point Of Sale</h2>
@endsection

