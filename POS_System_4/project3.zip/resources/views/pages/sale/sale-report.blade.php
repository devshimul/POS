@extends('master.app')

@section('main-content')

    <h2>Sales Reports </h2>


@endsection