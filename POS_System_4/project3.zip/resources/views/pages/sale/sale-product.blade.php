@extends('master.app')

@section('main-content')

    <h2>Sales Product </h2>


@endsection